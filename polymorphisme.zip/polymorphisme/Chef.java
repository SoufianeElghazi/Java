package polymorphisme;

public class Chef extends Salarier{

	public Chef(String nom) {
		super(nom);
		salaire = 1000;
	}

}
