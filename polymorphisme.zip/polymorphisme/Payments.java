package polymorphisme;

import java.util.ArrayList;

public class Payments {

	public static void main(String[] args) {
		
		Directeur Soufiane = new Directeur("Soufiane");
		Ouvirer Mohammed = new Ouvirer("amine");
		Chef Ali = new Chef("Ali");
		ArrayList<Salarier> salariés = new ArrayList<>();
		salariés.add(Soufiane);
		salariés.add(Mohammed);
		salariés.add(Ali);
		for (Salarier x :salariés) {
			x.afficheSalaire();
		}
		
	}

}
