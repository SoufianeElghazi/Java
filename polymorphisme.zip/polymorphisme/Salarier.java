package polymorphisme;

public class Salarier {
	protected double salaire;
	protected String nom;
	
	public Salarier(String nom) {
		this.nom = nom;
	}
	
	public String toString() {
		return nom;
		
	}
	public void afficheSalaire() {
		System.out.println("le salaire de "+ this +" est " + salaire); 
	}

}
