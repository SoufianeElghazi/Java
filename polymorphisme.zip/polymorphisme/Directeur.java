package polymorphisme;

public class Directeur extends Salarier{

	public Directeur(String nom) {
		super(nom);
		salaire = 1500;
	}

}
