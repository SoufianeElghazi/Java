package polymorphisme;

public class Ouvirer extends Salarier {

	public Ouvirer(String nom) {
		super(nom);
		salaire = 500;
	}

}
