package exception;

public class PersonneException extends Exception {

	private static final long serialVersionUID = 1L;

	public String toString() {
		return "la date de naissance est erronée";
		
	}

}
