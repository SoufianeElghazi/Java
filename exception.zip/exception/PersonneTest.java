package exception;

import java.time.LocalDate;
import java.time.Month;

public class PersonneTest {

	public static void main(String[] args) {
		Personne a = new Personne("ahmed");
		try {
			Personne b = new Personne("imane",LocalDate.of(2020, Month.APRIL, 10));
		}
		catch(PersonneException e){
			System.out.println(e.toString());
		}
			
		

	}

}
