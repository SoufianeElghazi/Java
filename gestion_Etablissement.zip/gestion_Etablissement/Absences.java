package gestion_Etablissement;

import java.util.Date;

public class Absences {
	
	private Date dateAbsence;
	private Element element;
	private boolean justification;
	//Constructeur:
	public Absences(Date dateAbsence, Element element, boolean justification) {
		
		this.dateAbsence = dateAbsence;
		this.element = element;
		this.justification = justification;
	}
	//Getters and Setters:
	public Date getDateAbsence() {
		return dateAbsence;
	}
	public void setDateAbsence(Date dateAbsence) {
		this.dateAbsence = dateAbsence;
	}
	public Element getElement() {
		return element;
	}
	public void setElement(Element element) {
		this.element = element;
	}
	public boolean isJustification() {
		return justification;
	}
	public void setJustification(boolean justification) {
		this.justification = justification;
	}
	

}
