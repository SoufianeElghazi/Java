package gestion_Etablissement;

import java.util.ArrayList;

public class Test {

	public static void main(String[] args) throws AbsenceException {
		
		//création des étudiants
		Etudiant soufiane = new Etudiant("1","soufiane","elghazi","elghazisoufiane02@gmail.com","icsd");
		Etudiant amine = new Etudiant("2","amine","maasri","aminemaasri@gmail.com","icsd");
		Etudiant amr = new Etudiant("3","amr","mouhi","amrmouhi@gmail.com","icsd");
		Etudiant yassine = new Etudiant("4","yassine","ouahib","yassinouahib@gmail.com","icsd");
		Etudiant zakarya = new Etudiant("5","zakarya","berhayla","zakaryaberhayla@gmail.com","icsd");
		//création des Professeurs
		Professeur Meryem = new Professeur("Meryem", "RHANOUI", "MaryemRAHNOUI@gmail.com");
		Professeur Badia = new Professeur("Badia", "ETTAKI", "BadiaETTAKI@gmail.com");
		//création des éléments		
		Element java = new Element("java",Meryem ,null);
		Element POO = new Element("POO",Meryem ,null);		
		Element Statistique = new Element("Statistique",Badia ,null);
		Element TI = new Element("TI",Badia ,null);
		//création des listes des élément qui se trouve dans le même block
		ArrayList<Element> programmationElements = new ArrayList<>();
		ArrayList<Element> mathematiqueElements = new ArrayList<>();
		programmationElements.add(java);
		programmationElements.add(POO);
		mathematiqueElements.add(TI);
		mathematiqueElements.add(Statistique);
		//création des modules		
		Module programmation = new Module("programmation orienté objet", programmationElements);
		Module mathematique = new Module("mathematique pour l'ingénieur", mathematiqueElements);
		//donner aux valeurs de nulles dans les élements leurs modules 
		java.setModule(programmation);
		POO.setModule(programmation);
		TI.setModule(mathematique);
		Statistique.setModule(mathematique);
		//création des absences
		Absences abs1 = new Absences(null, TI,false);
		Absences abs2 = new Absences(null, java,false);
		Absences abs3 = new Absences(null, POO,false);
		Absences abs4 = new Absences(null, Statistique,false);
		Absences abs5 = new Absences(null, TI,false);
		Absences abs6 = new Absences(null, TI,false);
		Absences abs7 = new Absences(null, TI,false);
		Absences abs8 = new Absences(null, TI,false);
		Absences abs9 = new Absences(null, TI,false);
		Absences abs10 = new Absences(null, TI,false);
		Absences abs11 = new Absences(null, TI,false);
		Absences abs12 = new Absences(null, TI,true);
		//essayer les méthodes:
		java.calculateNoteElement(amine, 17, 14, 0);
		POO.calculateNoteElement(amine, 12, 12, 0);
		Statistique.calculateNoteElement(amine, 5, 6, 0);
		TI.calculateNoteElement(amine, 2, 5, 0);
		
		System.out.println(mathematique.calculateNoteModule(amine)); 
		System.out.println(programmation.calculateNoteModule(amine)); 
		programmation.validerModule(amine);
		mathematique.validerModule(amine);
		
		
		amine.ajouterAbsence(abs1);
		amine.ajouterAbsence(abs2);
		amine.ajouterAbsence(abs3);
		amine.ajouterAbsence(abs4);
		amine.ajouterAbsence(abs5);
		amine.ajouterAbsence(abs6);
		amine.ajouterAbsence(abs7);
		amine.ajouterAbsence(abs8);
		amine.ajouterAbsence(abs9);
		amine.ajouterAbsence(abs10);
		amine.ajouterAbsence(abs11);
		amr.ajouterAbsence(abs12);
		amr.justifier(abs12, "maladie dans la tête");
		amine.display();
		amine.getAll_absences();
		amine.redoublant();
		amine.isBlame();

	}

}

