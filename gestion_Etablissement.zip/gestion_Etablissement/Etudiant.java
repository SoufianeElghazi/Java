package gestion_Etablissement;

import java.util.ArrayList;

public class Etudiant extends Personne {
	private String id_etudiant;
	private String filiere;
	private ArrayList<Absences> all_absences;
	private ArrayList<Double> all_notesModules;	
	private double note_totale;
	private boolean blame;
	private boolean redouble;
	final int authorizedAbsences =10;
	static ArrayList<Element> rattrapages;
	//Constructeur:
	public Etudiant(String id,String nom, String prenom, String email,String filiere) {
		super(nom, prenom, email);
		this.id_etudiant = id;
		this.filiere =filiere;		
	}
	//Getters and Setters:
	
	public String getId_etudiant() {
		return id_etudiant;
	}
	public ArrayList<Double> getAll_notesModules() {
		return all_notesModules;
	}
	public void setAll_notesModules(ArrayList<Double> all_notesModules) {
		this.all_notesModules = all_notesModules;
	}
	public void setId_etudiant(String id_etudiant) {
		this.id_etudiant = id_etudiant;
	}
	public String getFiliere() {
		return filiere;
	}
	public void setFiliere(String filiere) {
		this.filiere = filiere;
	}
	public ArrayList<Absences> getAll_absences() {
		return all_absences;
	}
	public void setAll_absences(ArrayList<Absences> all_absences) {
		this.all_absences = all_absences;
	}
	public double getNote_totale() {
		return note_totale;
	}
	public void setNote_totale(double note_totale) {
		this.note_totale = note_totale;
	}

	public boolean isBlame() {
		return blame;
	}

	public void setBlame(boolean blame) {
		this.blame = blame;
	}

	public boolean isRedouble() {
		return redouble;
	}

	public void setRedouble(boolean redouble) {
		this.redouble = redouble;
	}

	public int getAuthorizedAbsences() {
		return authorizedAbsences;
	}

	
	// calculer la note totale:
	public void calculateNoteTotale() {
		for(Double d:all_notesModules) {
			note_totale += d; 
		}
		note_totale /=all_absences.size();
	}
	// la methode display qui affiche les données de l'étudiant:
	@Override
	public void display() {
		System.out.println("Je suis " + this.getNom() + " " + this.getPrenom() +"il me reste "+ this.suiviAbsences() +" absences");
	}
	// la methode suiviAbsence qui affiche les absences restant:
	public int suiviAbsences() {
		int suivi = getAuthorizedAbsences()-all_absences.size();
		if(suivi<0) blame =true;
		return suivi;
}
	// la methode justifier qui retourne true si l'absence est justifié :
	public boolean justifier(Absences a,String reason ) throws AbsenceException {
		if((reason == null) || (reason == "")) {
			throw new AbsenceException();
		}else if(reason.contains("maladie")) {
			a.setJustification(true);
			System.out.println(this.getNom()+" "+this.getPrenom()+" votre absence est justifié");			
		}else System.out.println("absence non justifié!");
		
		return true;
	}
	// la methode ajouterAbsence qui ajoute l'absence non justifié au liste des absences:
	public void ajouterAbsence(Absences a) {
		if(a.isJustification()==false) {
			all_absences.add(a);
			System.out.println(this.getNom()+" "+this.getPrenom()+" est absent en : ");
			System.out.println("Le "+a.getDateAbsence()+"__ Non justifié");			
		}else {
			System.out.println(this.getNom()+" "+this.getPrenom()+" est absent en : ");
			System.out.println("Le "+a.getDateAbsence()+"__ justifié");
		}		
	}
	// la methode isBetterthan permet de comparer entre deux etudiants:
	public int isBetterthan(Etudiant etudiant) {
		int val;
		if(etudiant.note_totale ==this.note_totale) {
			val=0;
		}else if (etudiant.note_totale <this.note_totale) {
			val =1;
		}else {
			val =-1;			
		}		
		return val;
	}	
	// la methode redoublant qui retourne true si l'étudiant va redoubler 
	public boolean redoublant() {
		if((Module.ouverts.size()>5)||(note_totale<12)) redouble=true;
		return redouble;
	}
}

