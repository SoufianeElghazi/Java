package gestion_Etablissement;

public interface Comparable {
	boolean isBetterThan(Etudiant E);

}
