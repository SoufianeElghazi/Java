package gestion_Etablissement;

import java.util.ArrayList;

public class Element {
	private String nomElement;
	private Module module;
	private double note_element;
	private Professeur professeur;
	private int volumeHoraire =24;
	private ArrayList<Double> notesElement;
	private ArrayList<String> fillier;
	private double noteElement;
	static ArrayList<Element> rattrapages;
	//Constructeur:
	public Element(String nomElement, Professeur professeur,Module module) {
		this.nomElement = nomElement;
		this.professeur = professeur;
		this.module =module;
	}
	//Getters and Setters		
	public String getNomElement() {
		return nomElement;
	}
	public Module getModule() {
		return module;
	}

	public void setModule(Module module) {
		this.module = module;
	}

	public ArrayList<Double> getNotesElement() {
		return notesElement;
	}
	public void setNotesElement(ArrayList<Double> notesElement) {
		this.notesElement = notesElement;
	}
	public double getNoteElement() {
		return noteElement;
	}
	public void setNoteElement(double noteElement) {
		this.noteElement = noteElement;
	}
	public void setNomElement(String nomElement) {
		this.nomElement = nomElement;
	}
	public double getNote_element() {
		return note_element;
	}
	public void setNote_element(double note_element) {
		this.note_element = note_element;
	}
	public Professeur getProfesseur() {
		return professeur;
	}
	public void setProfesseur(Professeur professeur) {
		this.professeur = professeur;
	}
	public int getVolumeHoraire() {
		return volumeHoraire;
	}
	public void setVolumeHoraire(int volumeHoraire) {
		this.volumeHoraire = volumeHoraire;
	}
	public ArrayList<Double> getNotes() {
		return notesElement;
	}
	public void setNotes(ArrayList<Double> notes) {
		this.notesElement = notes;
	}
	public ArrayList<String> getFillier() {
		return fillier;
	}
	public void setFillier(ArrayList<String> fillier) {
		this.fillier = fillier;
	}
	// la methode calculateNoteElement qui retourne un double :
	public double calculateNoteElement(Etudiant e,double nControle,double nExame,double noteRatt){
		double nAssiduite =20;
		while(e.getAll_absences().size()<=10) {
			for(Absences a :e.getAll_absences()) {
				if(this.getNomElement().equals(a.getElement().getNomElement())) {
					nAssiduite -=0.75;
				}
			}
		}
		notesElement.add(nControle);
		notesElement.add(nExame);
		notesElement.add(nAssiduite);	 	
	 	noteElement = (nControle*4 +nExame*5 +nAssiduite*1)/10;
	 	if((e.isBlame()==false)&&(noteElement<12)&&noteElement>=5) {
	 		Element.rattrapages.add(this);
	 		System.out.println("rattrapage!!, calculer sa note de rattrapage!");
	 		noteElement=calculateRattrapage(e, noteRatt);
	 	}
	 	if((noteElement<5)) {
	 		Module.ouverts.add(this.module);
	 		System.out.println("le module"+this.module+" est ouvert!!");
	 	}
		return noteElement;
		
	}
	//la methode calculateRattrapage qui calcule la note de rattrapage:
	public double calculateRattrapage(Etudiant e,double noteRatt){
		if(noteRatt>=11.90) noteElement=12;
		else if(noteRatt>=noteElement) noteElement=noteRatt;		
		return noteElement;		
	}	
	// la methode displayElement qui affiche les données d'élement de module:
	public void displayElement() {
		
	}
	

}
