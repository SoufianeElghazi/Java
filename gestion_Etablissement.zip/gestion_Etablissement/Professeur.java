package gestion_Etablissement;

public class Professeur extends Personne {

	public Professeur(String nom, String prenom, String email) {
		super(nom, prenom, email);

	}

	@Override
	public void display() {

	}

}
