package gestion_Etablissement;

import java.util.ArrayList;

public class Module {
	private String nomModule;
	private ArrayList<Element> elements;
	private double noteModule;
	static ArrayList<Module> ouverts; 
	//Constructeur:
	public Module(String nomModule, ArrayList<Element> elements) {
		this.nomModule = nomModule;
		this.elements = elements;
	}
	//getters and setters:
	public String getNomModule() {
		return nomModule;
	}
	public void setNomModule(String nomModule) {
		this.nomModule = nomModule;
	}
	public ArrayList<Element> getElements() {
		return elements;
	}
	public void setElements(ArrayList<Element> elements) {
		this.elements = elements;
	}
	public double getNoteModule() {
		return noteModule;
	}
	public void setNoteModule(double noteModule) {
		this.noteModule = noteModule;
	}
	// la methode calculateNoteModule qui retourne un double :
	public double calculateNoteModule(Etudiant e) {
		noteModule =(elements.get(0).getNote_element()*2 +elements.get(1).getNote_element()*2)/4;
		e.getAll_notesModules().add(noteModule);
		return noteModule;
		
	}
	// la methode validerModule verifier si le module est validé:
	public boolean validerModule(Etudiant e) {
		boolean valide = false;
		if(elements.get(0).getNote_element()<5||elements.get(1).getNote_element()<5) {
			if((elements.get(0).getNote_element()+elements.get(1).getNote_element())/2>=12){
				Module.ouverts.remove(elements.get(0).getModule());
				valide = true;
			}	
		}else if(elements.get(0).getNote_element()<12 ||elements.get(0).getNote_element()>5) {
			if((elements.get(0).getNote_element()+elements.get(1).getNote_element())/2>=12) {
				Element.rattrapages.remove(elements.get(0));
				valide = true;
			}
		}else if(elements.get(1).getNote_element()<12 || (elements.get(1).getNote_element()>5)){
			if((elements.get(0).getNote_element()+elements.get(1).getNote_element())/2>=12) {
				Element.rattrapages.remove(elements.get(1));
				valide = true;
			}
		}else {
			valide = true;
		}
		return valide;
}
}



/***
 // la methode validerModule verifier si le module est validé:
	public boolean validerModule(Etudiant e) {
		boolean valide = false;
		if(elements.get(0).getNote_element()<5||elements.get(1).getNote_element()<5) {
			if((elements.get(0).getNote_element()+elements.get(1).getNote_element())/2<12){
				Module.ouverts.add(elements.get(0).getModule());
			}else {
				valide = true;
			}
			
		}else if(elements.get(0).getNote_element()<12 ||elements.get(0).getNote_element()>5) {
			if((e.isBlame()==false)&&(elements.get(0).getNote_element()+elements.get(1).getNote_element())/2<12) {
				Element.rattrapages.add(elements.get(0));
				
			}else {
				valide=true;
			}
		}else if(elements.get(1).getNote_element()<12 || (elements.get(1).getNote_element()>5)){
			if((e.isBlame()==false)&&(elements.get(0).getNote_element()+elements.get(1).getNote_element())/2<12) {
				Element.rattrapages.add(elements.get(1));				
			}else {
				valide = true;
			}
		}else {
			valide = true;
		}
		return valide;
} 
***/
