package Abstract;
public class Carre extends Form {
	
	private int coté;
	
	public Carre(int coté) {
		//super();
		this.coté = coté;
	}

	public  void calculerSurface() {
		System.out.println("la surface de carré est "+ coté*coté);
	}

}
