package Abstract;
public class Cercle {
	private int rayon;
	
	public Cercle(int rayon) {
		//super();
		this.rayon = rayon;
	}

	public  void calculerSurface() {
		System.out.println("la surface de cercle est "+ Math.PI * rayon*rayon);
	}
	
}