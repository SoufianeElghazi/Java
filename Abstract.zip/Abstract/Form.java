package Abstract;
public abstract class Form {
	
	public abstract void calculerSurface();
	public static void main(String[] args) {
		int jour =6;
		Carre carré = new Carre(2);
		Cercle cercle = new Cercle(4);
		carré.calculerSurface();
		cercle.calculerSurface();
		switch(jour)
		 {
		 case 1 : System.out.print("nous sommes le lundi"); break;
		 case 2 : System.out.print("nous sommes le mardi"); break;
		 case 3 : System.out.print("nous sommes le mercredi"); break;
		 case 4 : System.out.print("nous sommes le jeudi"); break;
		 case 5 : System.out.print("nous sommes le vendredi"); break;
		 case 6 : System.out.print("nous sommes le samedi"); break;
		case 7 : System.out.print("nous sommes le dimanche"); break;
		default : System.out.print("erreur");
		 }

	}

}
