package Vehicule;
import java.util.ArrayList;
public class TestVéhicule {

	public static void main(String[] args) {
		Camion c1 = new Camion("DAF",25); 
		Camion c2 = new Camion("Volvo",30);
		Voiture v1 = new Voiture("BMW", "blanche");
		Voiture v2 = new Voiture("Audi", "grise");
		v2.setNb_cheveaux(5);
		ArrayList<Vehicule> Structure = new ArrayList<>();
		Structure.add(c1);
		Structure.add(c2);
		Structure.add(v1);
		Structure.add(v2);		
		System.out.println("le prix de location de la voiture Audi pour une durée de 5 j est "+v2.calculerPrix(5)+" DH ");
		for (Vehicule i :Structure) {
			i.afficherdescription();
		}
		System.out.println("la capacité totale est :"+ Camion.nb_total_capacite);
		
		int cap = 0 ;
		for(Vehicule  i : Structure) {
			//System.out.println(i.getClass());
			if(i.getClass().toString().equals("class Vehicule.Camion") ) {
				
				Camion c =(Camion) i;
				cap +=c.getCapacite();
				
				
			}
			/***
			try {
				Camion c =(Camion) i;
				cap +=c.getCapacite();
			}catch(ClassCastException e){
				//System.out.println(e.toString());
				System.out.println(e.getMessage());
				//e.printStackTrace();
			}
				
			***/
		}
		
		System.out.println("la capacité totale des camions de la stuctures est "+cap);
		
	}

	}
