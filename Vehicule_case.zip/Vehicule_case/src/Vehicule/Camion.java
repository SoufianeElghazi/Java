package Vehicule;

public class Camion extends Vehicule {
	private int capacite;
	static int nb_total_capacite;

	public Camion(String marque,int capacite) {
		super(marque);
		this.capacite = capacite;
		nb_total_capacite = nb_total_capacite + capacite;
		
	}

	public int getCapacite() {
		return capacite;
	}

	public void setCapacite(int capacite) {
		this.capacite = capacite;
	}

	@Override
	public double calculerPrix(int j) {
		
		return tarif_ref * (capacite/2)*j;
	}

	@Override
	public void afficherdescription() {
		System.out.println("je suis une camion de marque "+this.getMarque()+".ma capacité est "+this.capacite);
		
	}
	

}
