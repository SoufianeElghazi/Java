package Vehicule;
public abstract class Vehicule {
	private String marque;
	final int tarif_ref = 50;
	public Vehicule(String marque) {
		
		this.marque = marque;
	}
	public String getMarque() {
		return marque;
	}
	public void setMarque(String marque) {
		this.marque = marque;
	}
	public abstract double calculerPrix(int j);
	public abstract void afficherdescription();
		
	
	
	

}
