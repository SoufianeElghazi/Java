package Vehicule;

public class Voiture extends Vehicule {
	private int nb_cheveaux ;
	private String coleur ;
	

	public Voiture(String marque,String coleur,int nbcheveaux) {
		super(marque);
		this.coleur = coleur;
		
		this.nb_cheveaux = nbcheveaux;
	}
	public Voiture(String marque,String coleur) {
		super(marque);
		this.coleur = coleur;
		
	}
	


	

	public int getNb_cheveaux() {
		return nb_cheveaux;
	}





	public void setNb_cheveaux(int nb_cheveaux) {
		this.nb_cheveaux = nb_cheveaux;
	}





	public String getColeur() {
		return coleur;
	}





	public void setColeur(String coleur) {
		this.coleur = coleur;
	}





	@Override
	public double calculerPrix(int j) {
		
		return tarif_ref * nb_cheveaux*j;
	}





	@Override
	public void afficherdescription() {
		System.out.println("je suis une voiture de marque "+this.getMarque()+".Ma coleur est "+this.coleur);
		
	}

}
