package exercice2;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;

import java.util.Scanner;

public class DoubleFIleAttente {
	public static void main(String[] args) {
		Deque<Integer> deque = new ArrayDeque<>();
		Scanner s = new Scanner(System.in);
		System.out.println("Donner deux entiers M et N représentant respectivement le nombre total d'entiers et la taille du sous-tableau:");
		int M =s.nextInt();
		int N = s.nextInt();
		s.close();
		
		System.out.println("entrer "+M+" entier ");
		for(int i=1; i<M+1; i++) {
			deque.addLast(s.nextInt());
			
		}
		System.out.println("votre deque est ");
		for(Integer i : deque) {
			System.out.print(i+" ");
		}
		ArrayList<ArrayList<Integer>> tab = new ArrayList<ArrayList<Integer>>(N);
		
		for(int i=1; i<N+1; i++) {
			//deque.getLast();
			tab.add(null);
		}

}
}