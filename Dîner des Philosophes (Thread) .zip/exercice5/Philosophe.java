package exercice5;

public class Philosophe extends Thread {
    int Num;
    static int Number=0;
    private Fourchette fourchette;
    public Philosophe(Fourchette fourchette){
    	super();
    	this.fourchette=fourchette;
        Num=Number;
        Number++;
    }
    
    private void manger(){
        System.out.format("le Philosophe\t%d\t mange\n", Num);
        try {Thread.sleep(500);
        } catch (InterruptedException e) {}
    }
    private void reflechir(){
        System.out.format("le Philosophe\t%d\t reflechit\n", Num);
        try { Thread.sleep(500);
        } catch (InterruptedException e) {}
    }
    public void run(){
        while(true){
            reflechir();
            fourchette.prendre();
            manger();
            fourchette.laisse();
        }
    }

}
