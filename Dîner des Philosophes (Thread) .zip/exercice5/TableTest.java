package exercice5;

public class TableTest {

	public static void main(String[] args) {
		Fourchette FR = new Fourchette();
        new Philosophe(FR).start();
        new Philosophe(FR).start();
        new Philosophe(FR).start();
        new Philosophe(FR).start();
        new Philosophe(FR).start();

	}

}
