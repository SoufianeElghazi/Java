package exercice5;

public class Fourchette {
	private boolean[] pris={false,false,false,false,false};
    public synchronized void laisse(){
	Philosophe phi=(Philosophe) Thread.currentThread();
	int Num=phi.Num;
	System.out.format("le Philosophe\t%d\tlaisse la fourchette\n", Num);
	pris[Num]=false;
	pris[((Num+1)%5)]=false;
	notifyAll();
    }
    public synchronized void prendre(){
	Philosophe phi=(Philosophe) Thread.currentThread();
	int Num=phi.Num;
	while(pris[((Num+1)%5)] || pris[Num]){
            try {
            	wait();
            }catch (InterruptedException e){}
        }
        System.out.format("la Philosophe\t%d\tprend la fourchette\n", Num);
        pris[Num]=true;
        pris[((Num+1)%5)]=true;
    }

}
