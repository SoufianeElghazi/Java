package Student;

public interface Trackable {
	int trackSituation();
}
