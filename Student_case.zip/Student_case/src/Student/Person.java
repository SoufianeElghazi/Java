package Student;
public abstract class  Person implements Trackable{
	private String firstName;
	private String lastName;
	private String school ="DataTruc" ;
	final int authorizedAbsence = 10;
	public Person(String lastName,String firstName) {
		this.firstName = firstName;
		this.lastName = lastName;
		
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSchool() {
		return school;
	}
	public void setSchool(String school) {
		this.school = school;
	}
	public int getAuthorizedAbsence() {
		return authorizedAbsence;
	}
	
	public abstract int trackSituation();
	public abstract void display();
	

}
