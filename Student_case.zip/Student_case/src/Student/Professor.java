package Student;

public class Professor extends Person {
	private int teachingHours;
	private int objectif;
	private String speciality;

	public Professor(String firstName, String lastName,  int teachingHours, int objectif,
			String speciality) {
		super(lastName,firstName);
		this.teachingHours = teachingHours;
		this.objectif = objectif;
		this.speciality = speciality;
	}

	public int getTeachingHours() {
		return teachingHours;
	}

	public void setTeachingHours(int teachingHours) {
		this.teachingHours = teachingHours;
	}

	public int getObjectif() {
		return objectif;
	}

	public void setObjectif(int objectif) {
		this.objectif = objectif;
	}

	public String getSpeciality() {
		return speciality;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}

	@Override
	public int trackSituation() {
		
		return teachingHours;
	}

	@Override
	public void display() {
		
		
	}
	
	
	

}
