package Student;

public class Student extends Person {
	private char group;
	private int allAbsences =0;
	

	public Student(String lastName,String firstName, char group, int allAbsences) {
		super(lastName,firstName);
		this.group = group ;
		
	}

	public char getGroup() {
		return group;
	}

	public void setGroup(char group) {
		this.group = group;
	}

	public int getAllAbsences() {
		return allAbsences;
	}

	public void setAllAbsences(int allAbsences) {
		this.allAbsences = allAbsences;
	}

	@Override
	public int trackSituation() {
		return getAuthorizedAbsence()-allAbsences;
	}

	@Override
	public void display() {
		System.out.println(getFirstName()+" a le plus d'absence!!");
		
		
	}
	public boolean justify(Absence a,String reason ) throws AbsenceException {
		if((reason == null) || (reason == "")) {
			throw new AbsenceException();
		}else {
			a.setJustification(true);
			System.out.println(getFirstName()+" votre absence est justifié");
			
		}
		
		return true;
	}
	
	
	
	public void addAbsence(Absence a) {
		if(a.isJustification()==false) {
			allAbsences +=1 ;
			System.out.println(this.getFirstName() +" est absent en : ");
			System.out.println("Le "+a.getDateAbsence()+"__ Non justifié");
			
			
		}else {
			System.out.println(this.getFirstName() +" est absent en : ");
			System.out.println("Le "+a.getDateAbsence()+"__ justifié");
		}
		
		
		
	}

}
