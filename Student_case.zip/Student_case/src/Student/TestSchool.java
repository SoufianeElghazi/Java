package Student;
import java.time.LocalDate;
import java.util.ArrayList;

public class TestSchool {

	public static void main(String[] args) {
		Student youssef = new Student("A","Youssef",'A',0);
		Student mohammed = new Student("A","Mohammed",'B',0);
		Student mouna = new Student("A","Mouna",'A',0);
		
		
		Absence a1 = new Absence( LocalDate.of(2018, 11, 03), false);
		Absence a2 = new Absence(LocalDate.of(2018, 11, 28), false);
		Absence a3 = new Absence(LocalDate.of(2018, 11, 26), false);
		youssef.addAbsence(a1);
		youssef.addAbsence(a2);
		mouna.addAbsence(a3);
		
		try {
			mouna.justify(a3, "Participation à une journée sportive");
			
		}catch(AbsenceException e){
			System.out.println(e.toString());
		}
		
		
		Professor ahmed = new Professor("B","Ahmed",12,60,"computer science");
		Professor imane = new Professor("A","Imane",32,80,"communication ");
		
		ArrayList<Student> classe = new ArrayList<>();
		classe.add(mohammed);
		classe.add(youssef);
		classe.add(mouna);
		
		int max_absence = classe.get(0).getAllAbsences();
		Student max_student =classe.get(0);
		for(Student student:classe) {
					
			if(student.getAllAbsences()>max_absence ) {
				max_absence = student.getAllAbsences();
				
				max_student =student;				
			}			
		}
		max_student.display();
		System.out.println(" il a "+max_absence);

	}

}
