package Interface;

public class Chien implements Animal {
	@Override
	public void manger() {
		System.out.println("je dévore");
		
	}

	@Override
	public void bouger() {
		System.out.println("je cours");
		
	}

	@Override
	public void crier() {
		System.out.println("j'aboie");
		
	}

}
