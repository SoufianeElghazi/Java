package Interface;

public class test {

	public static void main(String[] args) {
		Chien dog = new Chien();
		Serpent snick = new Serpent();
		dog.bouger();
		snick.bouger();
		dog.crier();
		snick.crier();
		
		

	}

}
