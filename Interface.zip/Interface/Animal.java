package Interface;
public interface Animal {
	void manger();
	void bouger();
	void crier() ;
		// TODO Auto-generated method stub
		
	}


