package Manager;
public abstract class Person {
	private String firstName;
	private String lastName;
	private float baseSalary;
	private String entreprise ="DataTruc";
	public Person(String lastName,String firstName,  float baseSalary) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.baseSalary = baseSalary;
		
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public float getBaseSalary() {
		return baseSalary;
	}
	public void setBaseSalary(float baseSalary) {
		this.baseSalary = baseSalary;
	}
	public String getEntreprise() {
		return entreprise;
	}
	public void setEntreprise(String entreprise) {
		this.entreprise = entreprise;
	}
	public abstract double calculateSalary();
	public abstract void display();
	
	
	
	

}
