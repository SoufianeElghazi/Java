package Manager;
import java.util.ArrayList;
public class Manager extends Person {
	private int respBonus;
	private ArrayList<Employee> employees ;
	public Manager(String lastName, String firstName, float baseSalary,int respBonus, ArrayList<Employee> employees) throws ManagerException {
		super(lastName, firstName, baseSalary);
		if(respBonus >0.1*baseSalary) {
			this.respBonus = respBonus;
			this.employees = employees;
		}else {
			throw new ManagerException();
		}
		
	}
	
	public int getRespBonus() {
		return respBonus;
	}

	public void setRespBonus(int respBonus) {
		this.respBonus = respBonus;
	}

	public ArrayList<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(ArrayList<Employee> employees) {
		this.employees = employees;
	}

	@Override
	public double calculateSalary() {
		
		return this.getBaseSalary()+this.respBonus;
	}
	@Override
	public void display() {
		
		
	}
	public void addEmploye(Employee e) {
		employees.add(e);
		
	}
	public void displayEmployees() {
		System.out.println("les employés du manager "+this.getFirstName()+" sont :");
		for(Employee em :employees) {
			System.out.println(em );
		}
		
	}
	public Employee meilleurEmploye() {
		Employee emp;
		emp =employees.get(0);
		for(int i =0; i <employees.size()-1;i++) {
			if(employees.get(i).isBetterthan(employees.get(i+1))==1) {
				emp =employees.get(i);
			}			
		}
		System.out.print("l’employé du manager " +this.getFirstName()+" avec la meilleure performance est :" );
		return emp;		
	}
	public ArrayList<Employee> worstEmployee(){
		ArrayList<Employee> worst_employees = new ArrayList<>() ;
		System.out.println("la liste des employés du manager "+this.getFirstName()+" dont les performances sont inférieurs à leurs objectifs sont :");
		for(int i =0; i <employees.size();i++) {
			if(employees.get(i).getBaseSalary()<employees.get(i).getPerformance()) {
				worst_employees.add(employees.get(i));
				}			
			}
		return worst_employees;
	}
	

}
