package Manager;


import java.util.ArrayList;




public class TestEntreprise {
	static float payroll(ArrayList<Person> staff) {
		float masse=0;
		for(Person p :staff) {
			masse += p.calculateSalary();
			/***
				if(p.getClass().toString().equals("class Person.Manager") ) {
				
				Manager m =(Manager) p;
				masse += m.calculateSalary();
				
				
			}else if(p.getClass().toString().equals("class Person.Employee") ) {
				
				Employee e =(Employee) p;
				masse += e.calculateSalary();
				
				
			}
			***/
		}
		return masse;		
	}

	public static void main(String[] args) {
		Employee youssef = new Employee("A", "Youssef", 11000, 3000, 300, null);
		Employee mohammed = new Employee("A", "Mohammed", 10000, 3000, 200, null);
		Employee mouna = new Employee("A", "Mouna", 11000, 3000, 100, null);
		
		ArrayList<Employee> youssef_mouna =new ArrayList<Employee>();
		youssef_mouna.add(youssef);
		youssef_mouna.add(mouna);
		ArrayList<Employee> mohammed_array =new ArrayList<>();
		mohammed_array.add(mohammed);
		
		
		try{
			Manager ahmed = new Manager("B", "Ahmed", 18000, 3000, youssef_mouna);
			Manager imane = new Manager("A", "Imane", 15000, 5000, mohammed_array);
			youssef.setManager(ahmed);
			mohammed.setManager(imane);
			mouna.setManager(ahmed);
			ahmed.displayEmployees();
			System.out.println(ahmed.meilleurEmploye());
			System.out.println(ahmed.worstEmployee());
			
			ArrayList<Person> staff = new ArrayList<>();
			staff.add(imane);
			staff.add(youssef);
			staff.add(ahmed);
			staff.add(mohammed);
			staff.add(mouna);
			System.out.println("la masse salariale globale de l’entreprise est :");
			System.out.println(payroll(staff));
			
		}catch(ManagerException e) {
			System.out.println(e.toString());
			
		}
		


	}

}
