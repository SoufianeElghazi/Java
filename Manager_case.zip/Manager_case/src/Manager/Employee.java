package Manager;

public class Employee extends Person implements Comparable {
	private int performance;
	private int perfBonus;
	private Manager manager;

	
	public Employee(String lastName, String firstName, float baseSalary, int perfBonus, int performance,
			Manager manager) {
		super(lastName, firstName, baseSalary);
		this.perfBonus = perfBonus;
		this.performance = performance;
		this.manager = manager;
	}
	

	@Override
	public String toString() {
		return getFirstName() + " ";
	}


	public int getPerformance() {
		return performance;
	}


	public void setPerformance(int performance) {
		this.performance = performance;
	}


	public int getPerfBonus() {
		return perfBonus;
	}


	public void setPerfBonus(int perfBonus) {
		this.perfBonus = perfBonus;
	}

	public Manager getManager() {
		return manager;
	}


	public void setManager(Manager manager) {
		this.manager = manager;
	}


	@Override
	public double calculateSalary() {
		double salaire ;
		if(this.perfBonus>1){
			salaire = this.getBaseSalary()+this.perfBonus;
		}else {
			salaire =this.getBaseSalary();
		}
		
		return salaire;
	}

	@Override
	public void display() {
		
		System.out.println("le prenom d'employé est :"+this.getFirstName());
		System.out.println("le nom d'employé est :"+this.getLastName());
	}


	@Override
	public int isBetterthan(Employee a) {
		int val;
		if(a.performance ==this.performance) {
			val=0;
		}else if (a.performance <this.performance) {
			val =1;
		}else {
			val =-1;
			
		}
		
		return val;
	}
	

}
