package Manager;

public interface Comparable {
	int isBetterthan(Employee a);

}
