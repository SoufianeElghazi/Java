/**
 * 
 */
/**
 * @author elgha
 *
 */
module Manager {
}